
<?php


$MS_PROTOCOL='dblib';
//$MS_DB_HOST='4.71.115.149';
$MS_DB_HOST='50.231.6.90';
$MS_DB_DATABASE='PersonalFinance';
$MS_DB_USERNAME='roidna';
$MS_DB_PASSWORD='V2%6!DKz)K]8DLf>';

try{
//$con = new PDO("mysql:host={$host};dbname={$db_name}", $username, $password);
//$db = new PDO("sqlsrv:Server={$MS_DB_HOST};Database={$MS_DB_DATABASE}", $MS_DB_USERNAME, $MS_DB_PASSWORD); 
$db = new PDO($MS_PROTOCOL.":host=".$MS_DB_HOST, $MS_DB_USERNAME, $MS_DB_PASSWORD);
}
catch(PDOException $exception){ echo "Connection error: " . $exception->getMessage();}
//*$serverName = "serverHost\\4.71.115.149"; //serverName\instanceName, portNumber (default is 1433)
//$connectionInfo = array( "Database"=>"PersonalFinance", "UID"=>"roidna", "PWD"=>"V2%6!DKz)K]8DLf>");
//$conn = sqlsrv_connect( $serverName, $connectionInfo);

//if( $conn ) {
  //   echo "Connection established.<br />";
//}else{
  //   echo "Connection could not be established.<br />";
    // die( print_r( sqlsrv_errors(), true));//
//}
//$query_credit_union_id = $db->prepare("insert into [inBalance].[dbo].[UserExam] (FirstName, LastName, Email, StreetAddress, City, State, Zip, MemberNumber, ReferringCreditUnionId, Score) values ('TEST','TEST','TEST','TEST','TEST','TEST','000000,'123456','001','100')");
//$query_credit_union_id->execute();
//check count

if($db){echo "DB connected";} else {echo "NO DB";}


$dbquery = "SELECT * FROM [PersonalFinance].[dbo].[UserExam] WHERE userexamid=87714088";
$dbs = $db->prepare($dbquery);
$dbs->execute();
$countdb = $dbs->rowCount();
echo "%%".$countdb."%%";


echo $dbquery;

$selectn = $db->prepare("SELECT * FROM [inBalance].[dbo].[UserExam]");
$selectn->execute();
//$countnew = $selectn->rowCount();
//echo $countnew;
if (count($selectn->fetchAll()) > '0') {
   echo 'soemthing--'.count($selectn->fetchAll());
   $f = $selectn->fetchAll();
   $emailn = $f[0]['Email'];
   $created = $f[0]['CreatedTimeStamp'];
   echo $emailn.'---'.$created;
}else{
   echo 'nothing';
}
?>
