<?php 
/* Database config */
/*$db_host		= 'mysql-balancepro-20191213.cjf7xkcjtoge.us-west-2.rds.amazonaws.com';
$db_user		= 'mysqlbalancepro';
$db_pass		= 'Int3l123!';
$db_database	= 'balancepro_dev_29_09_2023';*/
$db_encoding    = 'utf8'; 
/* End config */
$db_host = 'balancepro-1-14-24.cjf7xkcjtoge.us-west-2.rds.amazonaws.com';
$db_user = 'balancepro';
$db_pass = 'Int3l1234!';
$db_database = 'staging3';

$db = new PDO('mysql:host='.$db_host.';dbname='.$db_database, $db_user, $db_pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES ".$db_encoding));
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>

