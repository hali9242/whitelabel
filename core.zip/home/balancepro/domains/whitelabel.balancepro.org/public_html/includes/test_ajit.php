
<?php


$MS_PROTOCOL='dblib';
//$MS_DB_HOST='4.71.115.149';
$MS_DB_HOST='50.231.6.90';
$MS_DB_DATABASE='PersonalFinance';
$MS_DB_USERNAME='roidna';
$MS_DB_PASSWORD='V2%6!DKz)K]8DLf>';

try{
//$con = new PDO("mysql:host={$host};dbname={$db_name}", $username, $password);
//$db = new PDO("sqlsrv:Server={$MS_DB_HOST};Database={$MS_DB_DATABASE}", $MS_DB_USERNAME, $MS_DB_PASSWORD); 
$db = new PDO($MS_PROTOCOL.":host=".$MS_DB_HOST, $MS_DB_USERNAME, $MS_DB_PASSWORD);
}
$query_credit_union_id = $db->prepare("SELECT CreditUnionID  FROM [CallCenter].[dbo].[CreditUnion]");
          $query_credit_union_id->execute();
          $credit_union_id = $query_credit_union_id->fetchAll();
          if ( !empty( $credit_union_id ) ) {
            $credit_union_id = $credit_union_id[0]['CreditUnionId'];
          } else {
            $credit_union_id = 0;
          }
          echo $credit_union_id;
?>
